import Foundation

// ==============================================
//  main.swift — PUNTO DE ENTRADA DE YUSAKU 64
// ==============================================

// Cargamos todos los módulos de la interfaz
@main
class YusakuMain {
    
    static func main() {
        print("══════════════════════════════════════════")
        print("                                          ")
        print("   🎮   Y U S A K U   6 4   i O S        ")
        print("   Emulador — Construido desde cero       ")
        print("                                          ")
        print("   Capa de traducción: Yusaku64iOS        ")
        print("   Versión: 1.0 — 2026                    ")
        print("                                          ")
        print("══════════════════════════════════════════")
        print()
        print("✅ Sistema inicializado")
        print("✅ Cargando menú principal...")
        print()
        
        // Mostramos el menú principal
        let menu = MenuPrincipal()
        menu.mostrar()
    }
}
