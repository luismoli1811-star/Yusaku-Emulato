const char* yusaku_emulador_nombre(void) {
    return "Yusaku 64 — Emulador Switch 2";
}

int yusaku_soporte_arm64(void) {
    return 1;
}
