#include <stdio.h>
#include <string.h>

const char* yusaku_get_extension(const char* original) {
    if (strstr(original, ".nsp")) return ".nsp2";
    if (strstr(original, ".xci")) return ".xci2";
    if (strstr(original, ".nsz")) return ".nsz2";
    if (strstr(original, ".xcz")) return ".xcz2";
    if (strstr(original, ".nca")) return ".nca2";
    return ".ns2";
}

int yusaku_convert_file(const char* entrada, const char* salida) {
    FILE* in = fopen(entrada, "rb");
    if (!in) return -1;
    FILE* out = fopen(salida, "wb");
    if (!out) { fclose(in); return -2; }
    
    unsigned char buf[4096];
    size_t leido;
    while ((leido = fread(buf, 1, sizeof(buf), in)) > 0)
        fwrite(buf, 1, leido, out);
    
    fclose(in);
    fclose(out);
    return 0;
}
