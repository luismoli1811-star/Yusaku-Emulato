#include <stdio.h>
#include <string.h>

#define YUSAKU_MAGIC "YSK2"

int yusaku_verificar_formato(FILE* archivo) {
    char cabecera[4];
    if (fread(cabecera, 1, 4, archivo) != 4) return 0;
    return memcmp(cabecera, YUSAKU_MAGIC, 4) == 0;
}

int yusaku_escribir_cabecera(FILE* archivo) {
    return fwrite(YUSAKU_MAGIC, 1, 4, archivo) == 4;
}
