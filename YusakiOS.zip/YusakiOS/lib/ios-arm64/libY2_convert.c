#include <string.h>

void y2_extension(const char* orig, char* dest) {
    strcpy(dest, orig);
    strcat(dest, ".y2");
}

int y2_es_formato(const char* nombre) {
    return strstr(nombre, ".y2") != NULL;
}
