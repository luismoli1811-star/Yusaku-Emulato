#ifndef COMPATIBILIDAD_H
#define COMPATIBILIDAD_H

int yusaku_archivo_valido(const char* ruta);
void yusaku_listar_formatos();

#endif
