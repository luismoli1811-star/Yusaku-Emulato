#include "compatibilidad.h"
#include "traductor_base.h"
#include <cstdio>

int yusaku_archivo_valido(const char* ruta) {
    int tipo = yusaku_reconocer_formato(ruta);
    
    switch(tipo) {
        case 1:
            printf("✅ Formato compatible (Switch 1): %s\n", ruta);
            return 1;
        case 2:
            printf("✅ Formato Yusaku / Switch 2: %s\n", ruta);
            return 2;
        default:
            printf("❌ Formato no reconocido: %s\n", ruta);
            return 0;
    }
}

void yusaku_listar_formatos() {
    printf("\n📋 Formatos soportados:\n");
    printf("  🟢 Switch 1: .nsp .xci .nsz .xcz .nca\n");
    printf("  🟦 Yusaku:    .nsp2 .xci2 .nsz2 .xcz2 .nca2 .ns2\n\n");
}
