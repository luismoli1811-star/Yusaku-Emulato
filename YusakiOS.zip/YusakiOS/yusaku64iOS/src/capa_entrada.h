#ifndef CAPA_ENTRADA_H
#define CAPA_ENTRADA_H

int yusaku_capa_iniciar();
void yusaku_capa_cerrar();

#endif
