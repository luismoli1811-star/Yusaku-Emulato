#ifndef TRADUCTOR_BASE_H
#define TRADUCTOR_BASE_H

#include <string>
#include <cstring>

#define YUSAKU_VERSION "1.0"
#define YUSAKU_PLATAFORMA "iOS"

int yusaku_reconocer_formato(const char* nombre_archivo);
int yusaku_iniciar();
int yusaku_traducir_datos(const void* entrada, void* salida, size_t tamano);

#endif
