#include "capa_entrada.h"
#include "traductor_base.h"
#include <cstdio>

int yusaku_capa_iniciar() {
    if (!yusaku_iniciar()) {
        printf("❌ Error al iniciar la capa\n");
        return 0;
    }
    printf("✅ Capa de traducción activa y lista\n");
    return 1;
}

void yusaku_capa_cerrar() {
    printf("🔌 Capa de traducción finalizada\n");
}
