#include "traductor_base.h"
#include <cstdio>

int yusaku_reconocer_formato(const char* nombre_archivo) {
    if (!nombre_archivo) return -1;

    std::string n = nombre_archivo;
    
    if (n.find(".nsp") != std::string::npos ||
        n.find(".xci") != std::string::npos ||
        n.find(".nsz") != std::string::npos ||
        n.find(".xcz") != std::string::npos ||
        n.find(".nca") != std::string::npos) {
        return 1;
    }

    if (n.find(".nsp2") != std::string::npos ||
        n.find(".xci2") != std::string::npos ||
        n.find(".nsz2") != std::string::npos ||
        n.find(".xcz2") != std::string::npos ||
        n.find(".nca2") != std::string::npos ||
        n.find(".ns2")  != std::string::npos) {
        return 2;
    }

    return 0;
}

int yusaku_iniciar() {
    printf("══════════════════════════════════════\n");
    printf("  Yusaku64iOS — Capa de Traducción\n");
    printf("  Versión %s · %s\n", YUSAKU_VERSION, YUSAKU_PLATAFORMA);
    printf("  Construida desde cero\n");
    printf("══════════════════════════════════════\n");
    return 1;
}

int yusaku_traducir_datos(const void* entrada, void* salida, size_t tamano) {
    if (!entrada || !salida) return -1;
    std::memcpy(salida, entrada, tamano);
    return static_cast<int>(tamano);
}
