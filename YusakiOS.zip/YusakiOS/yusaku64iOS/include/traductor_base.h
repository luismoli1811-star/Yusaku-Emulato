#ifndef TRADUCTOR_BASE_H
#define TRADUCTOR_BASE_H

#include <cstddef>

#define YUSAKU_VERSION      "1.0"
#define YUSAKU_PLATAFORMA  "iOS"

// Reconocimiento de formatos
// Devuelve: 1=Switch1, 2=Yusaku/Switch2, 0=desconocido, -1=error
int yusaku_reconocer_formato(const char* nombre_archivo);

// Iniciar la capa
int yusaku_iniciar();

// Traducir datos entre formatos
int yusaku_traducir_datos(const void* entrada, void* salida, std::size_t tamano);

#endif
