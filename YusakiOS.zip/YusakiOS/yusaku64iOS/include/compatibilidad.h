#ifndef COMPATIBILIDAD_H
#define COMPATIBILIDAD_H

// Verificar si un archivo es soportado
int yusaku_archivo_valido(const char* ruta);

// Mostrar lista de formatos soportados
void yusaku_listar_formatos();

#endif
