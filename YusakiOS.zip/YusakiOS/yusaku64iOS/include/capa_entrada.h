#ifndef CAPA_ENTRADA_H
#define CAPA_ENTRADA_H

// Punto de entrada principal — llamado desde la interfaz
int yusaku_capa_iniciar();

// Cerrar la capa limpiamente
void yusaku_capa_cerrar();

#endif
