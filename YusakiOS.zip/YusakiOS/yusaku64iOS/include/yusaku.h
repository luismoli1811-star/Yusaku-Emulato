#ifndef YUSAKU_H
#define YUSAKU_H

// Archivo principal — incluye todo lo necesario
#include "traductor_base.h"
#include "compatibilidad.h"
#include "capa_entrada.h"

#endif
