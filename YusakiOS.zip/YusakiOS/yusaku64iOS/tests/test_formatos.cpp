#include <iostream>
#include "../src/traductor_base.h"

void prueba_formato(const char* nombre, int esperado) {
    int resultado = yusaku_reconocer_formato(nombre);
    std::cout << (resultado == esperado ? "✅" : "❌") 
              << " " << nombre 
              << " → esperado: " << esperado 
              << " · obtenido: " << resultado << std::endl;
}

int main() {
    std::cout << "════════════════════════════════════" << std::endl;
    std::cout << "  PRUEBA — Reconocimiento de formatos" << std::endl;
    std::cout << "════════════════════════════════════\n" << std::endl;

    // 🟢 Switch 1
    prueba_formato("juego.nsp", 1);
    prueba_formato("juego.xci", 1);
    prueba_formato("juego.nsz", 1);
    prueba_formato("juego.xcz", 1);
    prueba_formato("juego.nca", 1);

    std::cout << std::endl;

    // 🟦 Yusaku
    prueba_formato("juego.nsp2", 2);
    prueba_formato("juego.xci2", 2);
    prueba_formato("juego.nsz2", 2);
    prueba_formato("juego.xcz2", 2);
    prueba_formato("juego.nca2", 2);
    prueba_formato("juego.ns2", 2);

    std::cout << std::endl;

    // ❌ Desconocido
    prueba_formato("juego.xxx", 0);

    std::cout << "\n════════════════════════════════════" << std::endl;
    return 0;
}
