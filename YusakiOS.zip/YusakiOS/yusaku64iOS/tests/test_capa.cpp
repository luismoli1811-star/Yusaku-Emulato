#include <iostream>
#include "../src/capa_entrada.h"

int main() {
    std::cout << "════════════════════════════════════" << std::endl;
    std::cout << "  PRUEBA — Inicio y cierre de la capa" << std::endl;
    std::cout << "════════════════════════════════════\n" << std::endl;

    int iniciada = yusaku_capa_iniciar();
    
    if (iniciada) {
        std::cout << "\n✅ Prueba pasada: Capa iniciada correctamente\n" << std::endl;
        yusaku_capa_cerrar();
        std::cout << "\n✅ Prueba pasada: Capa cerrada limpiamente\n" << std::endl;
    } else {
        std::cout << "\n❌ Falló el inicio de la capa\n" << std::endl;
        return 1;
    }

    std::cout << "════════════════════════════════════" << std::endl;
    return 0;
}
