import Foundation

struct Ajustes {
    var resolucion = "1080p"
    var audio = "Estéreo"
    var formato = ".NSP2"
}
