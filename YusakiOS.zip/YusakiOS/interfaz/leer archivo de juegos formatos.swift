import Foundation

struct LectorFormatosJuegos {
    
    // 🟢 Formatos de juego — Switch 1
    let formatosSwitch = [
        ".nsp", ".xci", ".nca",  // sin comprimir
        ".nsz", ".xcz"            // comprimidos
    ]
    
    // 🟦 Formatos propios — Yusaku
    let formatosYusaku = [
        ".nsp2", ".xci2", ".nca2", ".ns2",  // sin comprimir
        ".nsz2", ".xcz2"                      // comprimidos
    ]
    
    func esValido(nombre: String) -> Bool {
        (formatosSwitch + formatosYusaku).contains { nombre.hasSuffix($0) }
    }
    
    func identificar(nombre: String) -> String {
        // Switch 1
        if nombre.hasSuffix(".nsp") { return "✅ NSP" }
        if nombre.hasSuffix(".xci") { return "✅ XCI" }
        if nombre.hasSuffix(".nca") { return "✅ NCA" }
        if nombre.hasSuffix(".nsz") { return "✅ NSZ · Comprimido" }
        if nombre.hasSuffix(".xcz") { return "✅ XCZ · Comprimido" }
        
        // Yusaku — sin el "64" aquí
        if nombre.hasSuffix(".nsp2") { return "🟦 NSP2" }
        if nombre.hasSuffix(".xci2") { return "🟦 XCI2" }
        if nombre.hasSuffix(".nca2") { return "🟦 NCA2" }
        if nombre.hasSuffix(".ns2")  { return "🟦 .NS2" }
        if nombre.hasSuffix(".nsz2") { return "🟦 NSZ2 · Comprimido" }
        if nombre.hasSuffix(".xcz2") { return "🟦 XCZ2 · Comprimido" }
        
        return "❌ Desconocido"
    }
    
    func listar() {
        print("════════════════════════════════════")
        print("  FORMATOS SOPORTADOS")
        print("════════════════════════════════════")
        print("\n 🟢 Switch")
        print("   .nsp .xci .nca")
        print("   .nsz .xcz  (comprimidos)")
        print("\n 🟦 Yusaku")
        print("   .nsp2 .xci2 .nca2 .ns2")
        print("   .nsz2 .xcz2  (comprimidos)")
        print("\n Capa de traducción: Yusaku64iOS")
        print("════════════════════════════════════")
    }
}
