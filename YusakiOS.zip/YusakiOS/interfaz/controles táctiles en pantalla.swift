import Foundation

struct ControlesTactiles {
    
    var visibles: Bool = true
    
    func disposicion() {
        print("════════════════════════════════════")
        print("  🎮 CONTROLES TÁCTILES EN PANTALLA")
        print("════════════════════════════════════")
        print()
        print("  ┌──────────────────────────────┐")
        print("  │  🡆🡅🡇🡄         ① ② ③ ④  │")
        print("  │  D-Pad          Botones      │")
        print("  │                              │")
        print("  │  L  R         -  +  SELECT   │")
        print("  └──────────────────────────────┘")
        print()
        print("  📍 D-Pad: flechas arriba/abajo/izquierda/derecha")
        print("  📍 ① = A   ② = B   ③ = X   ④ = Y")
        print("  📍 L = gatillo izquierdo  · R = gatillo derecho")
        print("  📍 - = Menú  · + = Inicio  · SELECT = Captura")
        print()
        print("════════════════════════════════════")
    }
    
    mutating func alternar() -> String {
        visibles.toggle()
        return visibles ? "✅ Controles visibles" : "🔳 Controles ocultos"
    }
    
    func personalizar() -> String {
        return "✏️ Modo personalización: arrastra los botones donde quieras"
    }
}
