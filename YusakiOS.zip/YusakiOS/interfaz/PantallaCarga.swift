import Foundation

struct PantallaCarga {
    func cargando(nombre: String) {
        print("Cargando: \(nombre) ...")
        print("Yusaku64iOS — Capa de traducción activa ✅")
    }
}
