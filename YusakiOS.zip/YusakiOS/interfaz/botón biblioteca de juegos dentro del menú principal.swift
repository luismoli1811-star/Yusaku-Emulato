import Foundation

struct BibliotecaJuegos {
    
    var juegos: [String] = []
    
    func mostrar() {
        print("════════════════════════════════════")
        print("  📚 BIBLIOTECA DE JUEGOS")
        print("════════════════════════════════════")
        
        if juegos.isEmpty {
            print("\n  No tienes juegos agregados aún")
            print("  Ve a \"Agregar juego\" para empezar")
        } else {
            print("\n  Total: \(juegos.count) juego(s)")
            print()
            for (indice, nombre) in juegos.enumerated() {
                print("  [\(indice + 1)] \(nombre)")
            }
        }
        
        print("\n  ↩️ Volver atrás")
        print("════════════════════════════════════")
    }
    
    mutating func agregarJuego(nombre: String) -> String {
        juegos.append(nombre)
        return "✅ Juego agregado a la biblioteca"
    }
    
    func seleccionarJuego(posicion: Int) -> String {
        guard posicion > 0, posicion <= juegos.count else {
            return "❌ No existe ese juego"
        }
        return "🎮 Cargando: \(juegos[posicion - 1])..."
    }
}
