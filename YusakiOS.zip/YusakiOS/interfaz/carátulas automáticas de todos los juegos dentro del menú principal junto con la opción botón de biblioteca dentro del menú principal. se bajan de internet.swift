import Foundation

struct CaratulasAutomaticas {
    
    var caratulasCargadas: [String: Bool] = [:]
    
    func mostrarEnMenuPrincipal() {
        print("════════════════════════════════════")
        print("  🖼️  CARÁTULAS AUTOMÁTICAS")
        print("════════════════════════════════════")
        print()
        print("  📚 [ Botón: Biblioteca de juegos ]")
        print("  ↳ Carátulas se muestran junto a cada juego")
        print()
    }
    
    mutating func descargarCaratula(nombreJuego: String) -> String {
        if caratulasCargadas[nombreJuego] == true {
            return "✅ Carátula ya disponible: \(nombreJuego)"
        }
        
        // Simula la descarga desde internet
        caratulasCargadas[nombreJuego] = true
        return "⬇️ Descargada: \(nombreJuego)"
    }
    
    func verEstado(nombreJuego: String) -> String {
        if caratulasCargadas[nombreJuego] == true {
            return "🖼️  Mostrando carátula"
        }
        return "🕐 Esperando descarga..."
    }
    
    func mostrarJuegoConCaratula(nombre: String) -> String {
        let estado = verEstado(nombre: nombre)
        return """
        ┌──────────────────────┐
        │     🖼️  CARÁTULA     │
        │                      │
        │   \(nombre.prefix(12))…   │
        │   \(estado)          │
        └──────────────────────┘
        """
    }
    
    mutating func actualizarBiblioteca(listaJuegos: [String]) -> String {
        var mensaje = ""
        for juego in listaJuegos {
            mensaje += descargarCaratula(nombreJuego: juego) + "\n"
        }
        return mensaje
    }
}
