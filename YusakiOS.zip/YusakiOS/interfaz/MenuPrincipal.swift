import Foundation

struct MenuPrincipal {
    func mostrar() {
        print("══════════════════════════════")
        print("    YUSAKU 64 — Menú Principal")
        print("══════════════════════════════")
        print("  1. Cargar juego")
        print("  2. Configuración")
        print("  3. Información")
        print("  4. Salir")
        print("══════════════════════════════")
    }
}
