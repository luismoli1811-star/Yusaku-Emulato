import Foundation

struct BotonAgregarJuego {
    
    func mostrarOpciones() {
        print("════════════════════════════════════")
        print("  AGREGAR JUEGO")
        print("════════════════════════════════════")
        print()
        print("  ¿Cómo quieres agregar el juego?")
        print()
        print("  📄  1. Como archivo individual")
        print("      (seleccionas el juego directamente)")
        print()
        print("  📁  2. Como carpeta completa")
        print("      (seleccionas la carpeta donde está el juego)")
        print()
        print("  ↩️  3. Volver atrás")
        print()
        print("════════════════════════════════════")
    }
    
    func seleccionar(opcion: Int) -> String {
        switch opcion {
        case 1:
            return "📄 Abriendo selector de archivos..."
        case 2:
            return "📁 Abriendo selector de carpetas..."
        case 3:
            return "↩️ Volviendo al menú..."
        default:
            return "❌ Opción no válida"
        }
    }
    
    func archivoSeleccionado(nombre: String) -> String {
        return "✅ Archivo cargado: \(nombre)"
    }
    
    func carpetaSeleccionada(nombre: String, cantidad: Int) -> String {
        return "✅ Carpeta cargada: \(nombre) — \(cantidad) juego(s) encontrado(s)"
    }
}
