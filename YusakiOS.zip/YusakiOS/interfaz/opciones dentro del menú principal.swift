import Foundation

struct OpcionesMenuPrincipal {
    
    func mostrarLista() {
        print("════════════════════════════════════")
        print("  OPCIONES — Yusaku 64 iOS")
        print("════════════════════════════════════")
        print()
        print("  📂 1. Agregar juego (carpeta o archivo)")
        print("  📚 2. Biblioteca de juegos")
        print("  ⚙️  3. Ajustes / Configuración")
        print("  🎮 4. Controles en pantalla")
        print("  📄 5. Información del sistema")
        print("  ❓ 6. Ayuda")
        print("  ↩️  7. Volver atrás")
        print()
        print("════════════════════════════════════")
        print("  Selecciona una opción:")
    }
    
    func seleccionar(opcion numero: Int) -> String {
        switch numero {
        case 1: return "Abrir selector de juegos..."
        case 2: return "Cargando biblioteca..."
        case 3: return "Abriendo ajustes..."
        case 4: return "Mostrando controles..."
        case 5: return "Yusaku 64 iOS — Versión 1.0"
        case 6: return "Ayuda y documentación"
        case 7: return "Volviendo al menú principal..."
        default: return "Opción no disponible"
        }
    }
}
